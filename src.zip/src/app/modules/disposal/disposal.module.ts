import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DisposalRoutingModule } from './disposal-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    DisposalRoutingModule
  ]
})
export class DisposalModule { }
