export interface Patients {
    name: string;
    age: number;
    address: string;
    mobile: string;
}

export const displayedColumns = [
    'name',
    'age',
    'address',
    'mobile',
    'createdAt',
    'actions',
];
