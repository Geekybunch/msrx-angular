export interface Businesses {
    businessName: string;
    productName: string;
    quantity: number;
    action: string;
    viewDetails: any;
}
export const displayedColumns = [
    'businessName',
    'productName',
    'quantity',
    'action',
    'viewDetails',
];
