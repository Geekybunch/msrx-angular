export interface StateAgencies {
    name: string;
    delegateName: string;
    email: string;
    actions: any;
}

export const displayedColumns = ['name', 'delegateName', 'email', 'actions'];
