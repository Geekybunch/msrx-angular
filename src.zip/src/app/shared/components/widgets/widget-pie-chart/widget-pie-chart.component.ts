import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-widget-pie-chart',
  templateUrl: './widget-pie-chart.component.html',
  styleUrls: ['./widget-pie-chart.component.scss']
})
export class WidgetPieChartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
