export const EXTRANCTION_METHODS = [
    'Butane Honey Oil',
    'Supercritical CO2 Oil',
    'Ethanol',
    'Water',
    'Isopropyl Oil',
    'Solventless',
];
