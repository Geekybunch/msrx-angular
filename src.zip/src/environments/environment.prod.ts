export const environment = {
    production: true,
    apiUrl: 'https://api.smartcannabisplatform.com/api/v1',
};
